import React, { useEffect } from 'react';
import { useLocation } from "react-router-dom";

const formJson = [{"type":"text","required":false,"label":"Text Field","className":"form-control","name":"text-1729575149253-0","access":false,"subtype":"text"},{"type":"text","required":false,"label":"Text Field","className":"form-control","name":"text-1729575152153-0","access":false,"subtype":"text"},{"type":"button","label":"Button","subtype":"button","className":"btn-success btn","name":"button-1729575155070-0","access":false,"style":"success"}]
   
const DynamicFormRender = () => {
  const location = useLocation();
  const { JsonData } = location.state || {};  // Accessing the passed data
     
  useEffect(() => {
    //alert(JSON.stringify(JsonData?.))
  }, []);
  // Function to render form elements dynamically based on the type
  const renderFormElement = (element) => {
    switch (element.type) {
        case "autocomplete":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <select className={element.className} name={element.name}>
                {element.values.map((option, index) => (
                  <option key={index} value={option.value} selected={option.selected}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          );

  
        case "checkbox-group":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              {element.values.map((checkbox, index) => (
                <div key={index}>
                  <input
                    type="checkbox"
                    name={checkbox.value}
                    defaultChecked={checkbox.selected}
                  />
                  {checkbox.label}
                </div>
              ))}
            </div>
          );
  
        case "date":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <input type="date" className={element.className} name={element.name} />
            </div>
          );
  
        case "file":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <input type="file" className={element.className} name={element.name} />
            </div>
          );
  
        case "header":
          return <h1 key={element.label}>{element.label}</h1>;
  
        case "paragraph":
          return <p key={element.label}>{element.label}</p>;
  
        case "number":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <input type="number" className={element.className} name={element.name} />
            </div>
          );
  
        case "text":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <input type="text" className={element.className} name={element.name} />
            </div>
          );
  
        case "radio-group":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              {element.values.map((radio, index) => (
                <div key={index}>
                  <input type="radio" name={element.name} value={radio.value} />
                  {radio.label}
                </div>
              ))}
            </div>
          );
  
        case "select":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <select className={element.className} name={element.name}>
                {element.values.map((option, index) => (
                  <option key={index} value={option.value} selected={option.selected}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          );
  
        case "textarea":
          return (
            <div key={element.name}>
              <label>{element.label}</label>
              <textarea className={element.className} name={element.name} />
            </div>
          );
  
      case 'text':
        return (
          <div key={element.name} className="form-group">
            <label>{element.label}</label>
            <input
              type={element.subtype}
              className={element.className}
              name={element.name}
              required={element.required}
            />
          </div>
        );
      case 'button':
        return (
          <button
            key={element.name}
            onClick={()=>alert('hi')}
            type={element.subtype === 'submit' ? 'submit' : 'button'}
            className={element.className}
          >
            {element.label}
          </button>
        );
      default:
        return null;
    }
  };

  return (
    <form>
      {JSON.parse(JsonData?.FormJson).map((element) => renderFormElement(element))}
    </form>
  );
};

export default DynamicFormRender;
